using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Proj3_Desai.Models;
using System.Diagnostics;

namespace Proj3_Desai.Controllers
{
    public class HomeController : Controller
    {
        private FlowerShopContext _context;
        private readonly ILogger<HomeController> _logger;

        public HomeController(FlowerShopContext flowerShopContext, ILogger<HomeController> logger) //had to combine the constructors
        { 
            _context = flowerShopContext;
            _logger = logger;
        }
        
        [HttpGet] //requests/retrives data
        //makes a dropdown menu of flower types (in the index the colors can be chosen with radio buttons
        public IActionResult Index()
        {
            List<SelectListItem> options = new List<SelectListItem>();
            options.Add(new SelectListItem { Text = "Roses", Value = "Roses", Selected = true });
            options.Add(new SelectListItem { Text = "Peonies", Value = "Peonies" });
            options.Add(new SelectListItem { Text = "Lilies", Value = "Lilies" });

            ViewBag.DropDownOptions = options;
            return View();
        }
        [HttpPost] //sends/submits data
        public IActionResult Submit(FlowerShopModel order) //submits order
        {
            if (ModelState.IsValid)
            {
                try
                {
                    order.DateTime = DateTime.Now;
                    _context.Add(order);
                    _context.SaveChanges();
                }
                catch (Exception ex)
                {
                    return View("Error", ex);
                }
            }
            else
            {
                return View("Error");
            }
            FlowerShopViewModel viewModel = new FlowerShopViewModel();
            viewModel.FlowerShop = order;
            viewModel.OrderInfo = Request.Headers["User-Agent"].ToString();
            return View(viewModel);
        }

        [HttpGet]
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult Orders(string filter)
        {
            ViewBag.Filter = filter;
            List<FlowerShopModel> orders;

            if(string.IsNullOrEmpty(filter))
            {
                orders = _context.Orders.ToList();
            }
            else
            {
                orders = (from r in _context.Orders
                          where r.Name.Contains(filter) select  r).ToList();
            }
            return View(orders);
        }
    }
}
