﻿namespace Proj3_Desai.Models
{
    public class FlowerShopViewModel
    {
        public FlowerShopModel FlowerShop { get; set; } //ties the model to the variable
        public string OrderInfo { get; set; } //creates orderinfo variable
    }
}
