﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Proj3_Desai.Models
{
    public class FlowerShopModel //required makes sure every field has to be filled
    {
        [Key] //tells the entity framework when it ceases to treat the id as the primary key of this entity
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)] //sees ID is a key and autoincrements and creates the keys for us
        public int Id { get; set; }

        [Required]
        public string Name { get; set; }
        [Required]
        public string Email { get; set; }
        [Required]
        public string Address { get; set; }
        [Required]
        public string City { get; set; }
        [Required]
        public string StateNme { get; set; }
        [Required]
        public string Zip { get; set; }
        [Required]
        [Display(Name = "Delivery Date")] // displays wording with spacing
        public string DeliveryDate { get; set; }
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        [Required]
        [Display(Name = "Confirm Password")]
        [Compare("Password", ErrorMessage = "Confirm password does not match. Try Again!")] //checks if the passwords match or else error message pops up
        [NotMapped] // doesn't add to the database table
        public string ConfirmPassword { get; set; }
        public DateTime DateTime { get; set; } //ties the date to the variable
        [Required]
        [Range(5,100)]
        public int Age { get; set; }
        [Required]
        public string Flowers { get; set; }
        [Required]
        public string Color { get; set; }
        [Required]
        [Display(Name = "AdditionalGreenery")]
        public string AdditionalGreenery { get; set; }
        [Required]
        [Display(Name = "Wrapping Style")]
        public bool WrappingStyle { get; set; } //yes or no question using boolean
    }
}