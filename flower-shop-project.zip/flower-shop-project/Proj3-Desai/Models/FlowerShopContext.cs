﻿using Microsoft.EntityFrameworkCore;

namespace Proj3_Desai.Models
{
    public class FlowerShopContext : DbContext
    {
        public FlowerShopContext(DbContextOptions<FlowerShopContext> options) : base(options)
        {
            
        }
        public DbSet<FlowerShopModel> Orders { get; set; }
    }
}
 