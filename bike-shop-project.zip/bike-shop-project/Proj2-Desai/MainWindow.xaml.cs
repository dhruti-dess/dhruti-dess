﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Proj2_Desai
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //setting variables
        private decimal baseBike = 0;
        private decimal cost = 0;
        string bikeType = "";
        string bikeFrameType = "";
        string addOns = "";
        public MainWindow()
        {
            InitializeComponent();
        }
        private void RadioButton_Checked(object sender, RoutedEventArgs e)
        {
            //cost goes up depending on what selection is made
            RadioButton radioButton = sender as RadioButton;
            if (Hybrid.IsChecked == true)
            {
                bikeType = "Hybrid Bike";
                baseBike = baseBike + 2000;
                cost = cost + 2000;
            }
            else if (Mountain.IsChecked == true)
            {
                bikeType = "Mountain Bike";
                baseBike = baseBike + 1500;
                cost = cost + 1500;
            }
            else if (Road.IsChecked == true)
            {
                bikeType = "Road Bike";
                baseBike = baseBike + 1000;
                cost = cost + 1000;
            }
            else if (Tricycle.IsChecked == true)
            {
                bikeType = "Tricycle";
                baseBike = baseBike + 500;
                cost = cost + 500;
            }
            else
            {
                baseBike = 0;
                cost = 0;
            }
        }


        private void ComboBox_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            //cost goes up depending on what selection is made
            ComboBoxItem selectedFrame = frameType.SelectedItem as ComboBoxItem;
            int frame = int.Parse(selectedFrame.Tag.ToString());
            switch (frame)
            {
                case 1: bikeFrameType = "Steel Frame"; cost = cost + 0; break;
                case 2: bikeFrameType = "Aluminum Frame"; cost = cost + 250; break;
                case 3: bikeFrameType = "Titanium Frame"; cost = cost + 4800; break;
                case 4: bikeFrameType = "Carbon Fiber Frame"; cost = cost + 2000; break;
            }
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            //cost goes up depending on what wselections are made
            //the varaible addons is updated to add the words for the message later
            if (gps.IsChecked == true)
            {
                addOns = addOns + "gps ";
                cost += 500;
            }
            if (helmet.IsChecked == true)
            {
                addOns = addOns + "helmet ";
                cost += 30;
            }
            if (kneePads.IsChecked == true)
            {
                addOns = addOns + "kneepads ";
                cost += 20;
            }
            if (comfort.IsChecked == true)
            {
                addOns = addOns + "comfort ";
                cost += 500;
            }
            if (color.IsChecked == true)
            {
                //this is my custom slider option
                addOns = addOns + "custom color ";
                cost += 50;
            }
            if (bikeType == "Tricycle")
            {
                //comfort and tricycle can't be ordered together
                comfort.IsChecked = false;
                comfort.IsEnabled = false;
                cost = cost - 500;
                addOns = "comfort cannot be chosen with Tricycle";
            }
            else
            {
                comfort.IsEnabled = true;
            }
        }

        private void SliderValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //the color values are set
            double red = sldRed.Value;
            double green = sldGreen.Value;
            double blue = sldBlue.Value;
            //the rectangle has a different fill based on what sliders are set to
            Color color = Color.FromArgb(255, (byte) red, (byte) green, (byte) blue);
            rctColorArea.Fill = new SolidColorBrush(color);
        }

        private void txtOrderName_TextChanged(object sender, TextChangedEventArgs e)
        {
            //the border color changes to red if the textbox is left empty
            if (string.IsNullOrEmpty(txtOrderName.Text))
            {
                txtOrderName.BorderBrush = new SolidColorBrush(Colors.Red);
                return;
            }
            else
            {
                txtOrderName.BorderBrush = new SolidColorBrush(Colors.White);
            }
        }
        //this will reset the form after it is called
        private void ResetForm()
        {
            //radio buttons are reset
            Hybrid.IsChecked = false;
            Mountain.IsChecked = false;
            Road.IsChecked = false;
            Tricycle.IsChecked = false;

            //combobox will be reset
            frameType.SelectedIndex = 0;

            //all the checkboxes will be unchosen again
            gps.IsChecked = false;
            helmet.IsChecked = false;
            kneePads.IsChecked = false;
            comfort.IsChecked = false;
            color.IsChecked = false;

            //the sliders will go back to transparent
            sldRed.Value = 0;
            sldGreen.Value = 0;
            sldBlue.Value = 0;

            //the text box for the name will be blank again
            txtOrderName.Text = "";

            //the totals will be reset to zero
            baseBike = 0;
            cost = 0;

            //all the addons will be erased
            addOns = "";

        }

        private void btnFinalizeCost_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtOrderName.Text) || baseBike == 0)
            {
                //if the selections aren't made, the message will pop up
                MessageBox.Show("Please make selections and fill out mandatory fields. \n*The Tricycle can not include the Comfort Package.");
                //the border color changes to red if the textbox is left empty
                txtBike.Background = new SolidColorBrush(Colors.Red);
                comfort.BorderBrush = new SolidColorBrush(Colors.Red);
                txtOrderName.BorderBrush = new SolidColorBrush(Colors.Red);
                return;
            }
            else
            {
                //message for order summary
                MessageBox.Show($"Thank you for your order {txtOrderName.Text}!\nYou ordered a {bikeType} with a {bikeFrameType}\nand {addOns}" +
                    $"\nThe total cost is: {cost:C}");
                //changes border/background colors back
                txtBike.Background = new SolidColorBrush(Colors.Transparent);
                comfort.BorderBrush = new SolidColorBrush(Colors.Transparent);
                txtOrderName.BorderBrush = new SolidColorBrush(Colors.White);
                ResetForm(); //call to reset the form
            }
        }
    }
}